# Newton-Polygon
Open-source power geometry python library.
